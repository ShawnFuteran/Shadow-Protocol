import pygame
import os

# Load background image
def load_background_image(image_name="background.jpg"):
    try:
        background_image = pygame.image.load(image_name).convert()
        background_image = pygame.transform.scale(background_image, (800, 600))
        return background_image
    except pygame.error:
        print(f"Error: Failed to load background image {image_name}")
        return None

# Load fonts
def load_font(font_name="freesansbold.ttf", size=30):
    try:
        font = pygame.font.Font(font_name, size)
        return font
    except pygame.error:
        print(f"Error: Failed to load font {font_name}")
        return pygame.font.Font(None, size)  # Return default font if custom font fails

# Load sound
def load_sound(sound_name="soundtrack.wav"):
    try:
        sound = pygame.mixer.Sound(sound_name)
        return sound
    except pygame.error:
        print(f"Error: Failed to load sound {sound_name}")
        return None

# Load all assets
def load_assets():
    background_image = load_background_image()
    font = load_font()
    return background_image, font
