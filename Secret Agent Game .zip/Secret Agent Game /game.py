import pygame, random, time, os, words, assets

# NEW: Global volume settings.
music_volume = 0.5
sound_effect_volume = 0.5

music_playing = True
secret_code = "safehouse"  # Global secret code

# Define display mappings for each level.
display_mapping = {
    1: {  # Now contains what was previously Level 2's UI/game words mapping.
        1: ["s"],
        2: [],
        3: ["a", "f"],
        4: ["e"]
    },
    2: {  # Now contains what was previously Level 1's secret words mapping.
        1: ["h"],
        2: [],
        3: ["o"],
        4: ["u"]
    },
    3: {  # Remains unchanged.
        1: ["s"],
        2: [],
        3: ["e"],
        4: []
    },
    4: {  # New Level 4 display mapping (example)
        1: ["v"],
        2: [],
        3: ["e"],
        4: ["r"]
    },
    5: {  # New Level 5 display mapping (example)
        1: ["i"],
        2: [],
        3: ["l"],
        4: ["e"]
    }
}

# List of level music tracks for gameplay.
level_music_list = [
    "Night Out by @LiQWYD Saxophone Vlog Music (No Copyright).mp3",
    "Epic Action Cinematic by Infraction [No Copyright Music]  Heroes.mp3",
    "Upbeat Funk Happy by Infraction [No Copyright Music]  Event Vibe.mp3",
    "Upbeat Rock Funk by Infraction [No Copyright Music]  Smiling Faces.mp3",
    "Upbeat Vlog and Event Music by Infraction [No Copyright Music]  Early Morning.mp3"
]

# Custom event for music end.
MUSIC_END_EVENT = pygame.USEREVENT + 1

# Global variables for music.
current_level_track = None
remaining_tracks = []

pygame.init()
info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Shadow Protocol")

# Load assets and music.
background_image_asset, font_asset = assets.load_assets()  # returns (background_image, font)
pygame.mixer.music.set_volume(music_volume)  # Use global music_volume

def load_image(image_name, scale=(WIDTH, HEIGHT)):
    if not os.path.exists(image_name):
        print(f"Error: {image_name} does not exist. Using fallback image.")
        return pygame.Surface(scale)
    try:
        img = pygame.image.load(image_name).convert()
        return pygame.transform.scale(img, scale)
    except pygame.error:
        print(f"Error: Could not load image {image_name}.")
        return pygame.Surface(scale)

background_image = load_image("background.jpg")

# Fonts
font = pygame.font.Font(None, 40)
large_font = pygame.font.Font(None, 80)
small_font = pygame.font.Font(None, 30)
extra_large_font = pygame.font.Font(None, 90)
intro_font = pygame.font.SysFont('Arial', 28)
round_title_font = pygame.font.Font(None, 60)
round_text_font = pygame.font.Font(None, 50)

# Global level completion tracker:
# Normal levels are now 1–5; secret level is 0.
completed_levels = {0: False, 1: False, 2: False, 3: False, 4: False, 5: False}

def fit_text(text, initial_size, max_width, font_name=None, color=(255,255,255)):
    current_size = initial_size
    font_obj = pygame.font.Font(font_name, current_size)
    rendered = font_obj.render(text, True, color)
    while rendered.get_width() > max_width and current_size > 10:
         current_size -= 1
         font_obj = pygame.font.Font(font_name, current_size)
         rendered = font_obj.render(text, True, color)
    return rendered, font_obj

def countdown_timer(start, duration):
    return max(duration - (time.time() - start), 0)

def clear_screen():
    screen.fill((0, 0, 0))
    screen.blit(background_image, (0, 0))

def wrap_text(text, max_w, font_obj=font):
    words_list = text.split()
    lines, current = [], ""
    for word in words_list:
        test_line = current + word + " "
        if font_obj.size(test_line)[0] < max_w:
            current = test_line
        else:
            lines.append(current.strip())
            current = word + " "
    if current:
        lines.append(current.strip())
    return lines

def show_intro():
    intro_text = [
        "SHADOW PROTOCOLS INITIATED", "", "WELCOME, SECRET AGENT!", "",
        "You’ve been selected for a high-stakes mission to",
        "decrypt critical messages and prevent global disaster.",
        "A cryptic transmission, intercepted by your agency,",
        "holds the key to saving the world. The information",
        "is encrypted, and only you have the skills to",
        "uncover the truth.", "",
        "Your mission, should you choose to accept it, is to",
        "decrypt the code words and crack the cipher before",
        "time runs out. You’ll face growing challenges, but",
        "every decoded message brings you closer to the truth.", "",
        "The world is counting on you.", "", "**INSTRUCTIONS**",
        "• Type the decrypted message when prompted.",
        "• Try different shifts to decrypt the Caesar cipher.",
        "• Remember, every second counts!", "",
        "This message will self-destruct in 15 seconds…", "just kidding…"
    ]
    wrapped = []
    for line in intro_text:
        wrapped.extend(wrap_text(line, WIDTH - 40, font))
    typed_lines = []
    char_delay = 40
    line_delay = 250
    y_start = 100
    clock = pygame.time.Clock()
    skip_intro = False
    for i, line in enumerate(wrapped):
        current_typed = ""
        for char in line:
            current_typed += char
            clear_screen()
            for j, t_line in enumerate(typed_lines):
                ts = font.render(t_line, True, (255,255,255))
                screen.blit(ts, ((WIDTH - ts.get_width())//2, y_start + j*(font.get_height()+10)))
            ts = font.render(current_typed, True, (255,255,255))
            screen.blit(ts, ((WIDTH - ts.get_width())//2, y_start + i*(font.get_height()+10)))
            pygame.display.update()
            start_delay = time.time()
            while time.time() - start_delay < char_delay / 1000.0:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        return
                    if event.type == pygame.KEYDOWN:
                        skip_intro = True
                if skip_intro:
                    break
                clock.tick(60)
            if skip_intro:
                break
        if skip_intro:
            break
        typed_lines.append(current_typed)
        start_delay = time.time()
        while time.time() - start_delay < line_delay / 1000.0:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    skip_intro = True
            if skip_intro:
                break
            clock.tick(60)
        if skip_intro:
            break
    if skip_intro:
        typed_lines = wrapped
    clear_screen()
    for i, line in enumerate(typed_lines):
        ts = font.render(line, True, (255,255,255))
        screen.blit(ts, ((WIDTH - ts.get_width())//2, y_start+i*(font.get_height()+10)))
    prompt_text = "Press ENTER to continue"
    cont = small_font.render(prompt_text, True, (255,255,255))
    cont_rect = cont.get_rect(center=(WIDTH//2, HEIGHT-70))
    pygame.draw.rect(screen, (255,255,255), cont_rect.inflate(20,10), 2)
    screen.blit(cont, cont_rect)
    start_time = time.time()
    while True:
        remaining = max(15 - (time.time()-start_time),0)
        clear_screen()
        for i, line in enumerate(typed_lines):
            ts = font.render(line, True, (255,255,255))
            screen.blit(ts, ((WIDTH - ts.get_width())//2, y_start+i*(font.get_height()+10)))
        pygame.draw.rect(screen, (255,255,255), cont_rect.inflate(20,10),2)
        screen.blit(cont, cont_rect)
        timer_font = pygame.font.Font(None,50)
        timer_text = timer_font.render(f"{int(remaining)}", True, (255,255,255))
        screen.blit(timer_text, (WIDTH-timer_text.get_width()-20, (HEIGHT-timer_text.get_height())//2))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                run_level_menu()
                return
        if time.time()-start_time >= 15:
            go_to_main_menu()
            return

def go_to_main_menu():
    # NEW: Set sound effect volume for the explosion sound.
    explosion_sound = pygame.mixer.Sound("Explosion Meme (EARRAPE).mp3")
    explosion_sound.set_volume(sound_effect_volume)
    explosion_sound.play()
    global completed_levels, current_level_track, remaining_tracks
    completed_levels = {0: False, 1: False, 2: False, 3: False, 4: False, 5: False}
    current_level_track = None
    remaining_tracks = []
    print("Returning to the main menu...")
    main_menu()

def failed_mission():
    global completed_levels, current_level_track, remaining_tracks
    completed_levels = {0: False, 1: False, 2: False, 3: False, 4: False, 5: False}
    current_level_track = None
    remaining_tracks = []
    clear_screen()
    msg = large_font.render("You failed the mission", True, (255,0,0))
    screen.blit(msg, ((WIDTH - msg.get_width())//2, (HEIGHT - msg.get_height())//2))
    pygame.display.update()
    time.sleep(1)
    main_menu()

def show_completion_message():
    clear_screen()
    msg = large_font.render("Congratulations! You completed all levels!", True, (0,255,0))
    screen.blit(msg, ((WIDTH - msg.get_width())//2, (HEIGHT - msg.get_height())//2))
    pygame.display.update()
    time.sleep(3)

def display_text_screen(lines, title, action=None):
    running = True
    while running:
        clear_screen()
        ts = large_font.render(title, True, (255,255,255))
        screen.blit(ts, ((WIDTH - ts.get_width())//2, 80))
        total_height = len(lines) * (intro_font.get_height()+10)
        y_offset = (HEIGHT - total_height)//2
        y = y_offset
        for line in lines:
            ts = intro_font.render(line, True, (255,255,255))
            screen.blit(ts, ((WIDTH - ts.get_width())//2, y))
            y += intro_font.get_height()+10
        cont = small_font.render("Press ENTER to continue", True, (255,255,255))
        screen.blit(cont, ((WIDTH - cont.get_width())//2, HEIGHT-70))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN and action:
                action()
                return

def start_game():
    global current_level_track, remaining_tracks
    current_level_track = None
    remaining_tracks = []
    pygame.mixer.music.load("Mission Impossible 7 Theme Movie Soundtrack  [No Copyright].mp3")
    if music_playing:
        pygame.mixer.music.play(-1,0.0)
    show_intro()
    run_level_menu()

class Button:
    def __init__(self, text, x, y, action=None, font_size=80, color=(255,255,255), hover_color=(169,169,169)):
        self.text = text
        self.font = pygame.font.Font(None, font_size)
        self.action = action
        self.color = color
        self.hover_color = hover_color
        self.is_hovered = False
        self.disabled = False
        self.width = self.font.size(text)[0] + 20
        self.height = self.font.size(text)[1] + 20
        self.rect = pygame.Rect(x, y, self.width, self.height)

    def draw(self, surface):
        draw_color = (100,100,100) if self.disabled else (self.hover_color if self.is_hovered else self.color)
        pygame.draw.rect(surface, draw_color, self.rect, 2)
        ts = self.font.render(self.text, True, (255,255,255))
        surface.blit(ts, (self.rect.centerx - ts.get_width()//2,
                          self.rect.centery - ts.get_height()//2))

    def check_hover(self, pos):
        self.is_hovered = self.rect.collidepoint(pos)

    def click(self, pos):
        if self.disabled:
            return
        if self.rect.collidepoint(pos) and self.action:
            self.action()

# NEW: Slider class for the settings menu.
class Slider:
    def __init__(self, label, x, y, width, min_value=0.0, max_value=1.0, step=0.1, initial_value=0.5):
        self.label = label
        self.x = x
        self.y = y
        self.width = width
        self.height = 20
        self.min_value = min_value
        self.max_value = max_value
        self.step = step
        self.value = initial_value
        self.knob_radius = 10
        self.dragging = False

    def draw(self, surface, font_obj):
        # Draw label with current value.
        label_surface = font_obj.render(f"{self.label}: {self.value:.1f}", True, (255,255,255))
        surface.blit(label_surface, (self.x, self.y - 30))
        # Draw slider track.
        pygame.draw.rect(surface, (200,200,200), (self.x, self.y, self.width, self.height))
        # Draw knob.
        knob_x = self.x + int((self.value - self.min_value) / (self.max_value - self.min_value) * self.width)
        pygame.draw.circle(surface, (100,100,100), (knob_x, self.y + self.height//2), self.knob_radius)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            knob_x = self.x + int((self.value - self.min_value) / (self.max_value - self.min_value) * self.width)
            if (mouse_x - knob_x)**2 + (mouse_y - (self.y + self.height//2))**2 <= self.knob_radius**2:
                self.dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            mouse_x, _ = event.pos
            relative_x = mouse_x - self.x
            relative_x = max(0, min(self.width, relative_x))
            ratio = relative_x / self.width
            new_value = self.min_value + ratio * (self.max_value - self.min_value)
            # Round to nearest step.
            steps = round((new_value - self.min_value) / self.step)
            self.value = self.min_value + steps * self.step
            self.value = max(self.min_value, min(self.max_value, self.value))

def run_level_menu():
    # Create buttons for Levels 1 to 5.
    btns = []
    level_names = ["Level 1", "Level 2", "Level 3", "Level 4", "Level 5"]
    start_y = 220
    for i, name in enumerate(level_names, start=1):
        btn = Button(name, 0, start_y, action=lambda lvl=i: start_level(lvl), font_size=80)
        btn.rect.x = (WIDTH - btn.rect.width)//2
        if completed_levels[i]:
            btn.disabled = True
        btns.append(btn)
        start_y += 100

    btn_back = Button("Back to Main Menu", 0, start_y, action=main_menu, font_size=60)
    btn_back.rect.x = (WIDTH - btn_back.rect.width)//2
    btns.append(btn_back)

    # Add secret level button if all normal levels are completed.
    if all(completed_levels[i] for i in range(1,6)):
        btn_secret = Button("Level 0", 0, 120, action=lambda: start_level("secret"), font_size=80)
        if completed_levels[0]:
            btn_secret.disabled = True
        btn_secret.rect.x = (WIDTH - btn_secret.rect.width)//2
        btns.insert(0, btn_secret)

    level_screen(btns)

def level_screen(level_buttons):
    running = True
    title_text = large_font.render("Choose a Difficulty", True, (255,255,255))
    while running:
        clear_screen()
        screen.blit(title_text, ((WIDTH - title_text.get_width())//2, 50))
        for button in level_buttons:
            button.draw(screen)
            if button.text in ["Level 0", "Level 1", "Level 2", "Level 3", "Level 4", "Level 5"]:
                lvl = 0 if button.text == "Level 0" else int(button.text.split()[1])
                if completed_levels[lvl]:
                    pygame.draw.line(screen, (255,255,255),
                                     (button.rect.left, button.rect.centery),
                                     (button.rect.right, button.rect.centery), 3)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for button in level_buttons:
                    button.click(event.pos)
            elif event.type == pygame.MOUSEMOTION:
                for button in level_buttons:
                    button.check_hover(event.pos)

def start_level(level):
    global current_level_track, remaining_tracks
    # Start level music if needed.
    if level in ["secret"] or isinstance(level, int):
        if current_level_track is None or not pygame.mixer.music.get_busy():
            if not remaining_tracks:
                remaining_tracks = list(level_music_list)
            current_level_track = random.choice(remaining_tracks)
            remaining_tracks.remove(current_level_track)
            pygame.mixer.music.load(current_level_track)
            pygame.mixer.music.play()  # Play once.
            pygame.mixer.music.set_endevent(MUSIC_END_EVENT)
    # Handle normal levels (levels 1-5) vs. secret level.
    if level != "secret":
        level_num = level if isinstance(level, int) else {"easy": 1, "medium": 2, "hard": 3}[level]
        available_questions = list(range(1, 21))
        round_counter = 0
        while round_counter < 4:
            if not play_round(level, round_counter, available_questions):
                failed_mission()
                return
            round_counter += 1
        completed_levels[level_num] = True
        if all(completed_levels[i] for i in range(1, 6)):
            show_completion_message()
            secret_level_prompt()
        else:
            run_level_menu()
    else:
        available_questions = list(range(1, len(words.encoded_words[0]) + 1))
        random.shuffle(available_questions)
        round_counter = 0
        while round_counter < 4:
            if not play_round(level, round_counter, available_questions):
                failed_mission()
                return
            round_counter += 1
        completed_levels[0] = True
        current_level_track = None
        remaining_tracks = []
        for i in range(0, 6):
            completed_levels[i] = False
        display_credits()

def play_round(level, round_number, available_questions):
    if level == "secret":
        level_num = 0
        header_text = f"Level 0 - Round {round_number+1}"
    else:
        level_num = level if isinstance(level, int) else {"easy": 1, "medium": 2, "hard": 3}[level]
        header_text = f"Level {level_num} - Round {round_number+1}"
    if not available_questions:
        return False
    rand_num = random.choice(available_questions)
    available_questions.remove(rand_num)
    ca_sample = words.correct_answer[level_num]["answer" + str(rand_num)]
    box_width = max(300, round_text_font.size(ca_sample)[0] + 50)
    input_box = pygame.Rect(WIDTH//2 - box_width//2, 450, box_width, 60)
    user_input = ""
    back_button = Button("Back to Level Menu", (WIDTH - 400)//2, HEIGHT-140, action=run_level_menu, font_size=60)
    tries = 0
    max_attempts = 3
    start_time = time.time()
    while True:
        clear_screen()
        if level_num in display_mapping:
            letters_for_this_round = display_mapping[level_num].get(round_number+1, [])
            if letters_for_this_round:
                letter_font = pygame.font.SysFont('Arial', 50, bold=True)
                letter_str = " ".join(letters_for_this_round)
                screen.blit(letter_font.render(letter_str, True, (255,255,255)), (20, 50))
        header_surface, _ = fit_text(header_text, 60, WIDTH-40)
        screen.blit(header_surface, ((WIDTH - header_surface.get_width())//2, 50))
        encrypted_surface, _ = fit_text("Encrypted: [HIDDEN]", 50, WIDTH-40)
        screen.blit(encrypted_surface, ((WIDTH - encrypted_surface.get_width())//2, 180))
        remaining = countdown_timer(start_time, 60)
        timer_surface, _ = fit_text(f"Time Left: {int(remaining)}", 50, WIDTH-40)
        screen.blit(timer_surface, ((WIDTH - timer_surface.get_width())//2, 280))
        attempts_left = max_attempts - tries
        attempts_surface, _ = fit_text(f"Attempts Left: {attempts_left}", 50, WIDTH-40)
        screen.blit(attempts_surface, ((WIDTH - attempts_surface.get_width())//2, 330))
        cw = words.correct_word[level_num]["CW" + str(rand_num)]
        hint_text = f"Hint: {words.encoded_words[level_num][cw]}"
        hint_surface, _ = fit_text(hint_text, 50, WIDTH-40)
        screen.blit(hint_surface, ((WIDTH - hint_surface.get_width())//2, 380))
        pygame.draw.rect(screen, (255,255,255), input_box, 2)
        if user_input.strip() != "":
            input_surface = round_text_font.render(user_input, True, (255,255,255))
        else:
            input_surface = round_text_font.render("_", True, (255,255,255))
        screen.blit(input_surface, (input_box.x+10, input_box.y+10))
        back_button.draw(screen)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == MUSIC_END_EVENT:
                global remaining_tracks, current_level_track
                if not remaining_tracks:
                    remaining_tracks = list(level_music_list)
                new_track = random.choice(remaining_tracks)
                remaining_tracks.remove(new_track)
                current_level_track = new_track
                pygame.mixer.music.load(new_track)
                pygame.mixer.music.play()
                pygame.mixer.music.set_endevent(MUSIC_END_EVENT)
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    pass
                if back_button.rect.collidepoint(event.pos):
                    back_button.action()
                    return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if user_input.strip() == "":
                        continue
                    if remaining > 0 and check_decryption(level, user_input, rand_num):
                        return True
                    else:
                        tries += 1
                        if tries < max_attempts:
                            wrong_msg = round_text_font.render("Wrong, try again!", True, (255,0,0))
                            clear_screen()
                            screen.blit(wrong_msg, ((WIDTH - wrong_msg.get_width())//2, HEIGHT//2))
                            pygame.display.update()
                            time.sleep(1)
                            user_input = ""
                        else:
                            return False
                elif event.key == pygame.K_BACKSPACE:
                    user_input = user_input[:-1]
                else:
                    user_input += event.unicode
                new_width = max(300, round_text_font.size(user_input)[0] + 20)
                input_box.width = new_width
                input_box.x = WIDTH // 2 - new_width // 2
        if remaining <= 0:
            return False

def display_mapping_for_round(level_num, round_number):
    return display_mapping.get(level_num, {}).get(round_number, [])

def check_decryption(level, user_input, rand_num):
    if level == "secret":
        level_num = 0
    else:
        level_num = level if isinstance(level, int) else {"easy": 1, "medium": 2, "hard": 3}[level]
    ca = words.correct_answer[level_num]["answer" + str(rand_num)]
    return user_input.lower() == ca.lower()

def secret_level_prompt():
    clear_screen()
    prompt = "Secret Level Unlocked! Would you like to continue?"
    prompt_surface = large_font.render(prompt, True, (255,255,255))
    screen.blit(prompt_surface, ((WIDTH - prompt_surface.get_width())//2, HEIGHT//2 - 100))
    continue_btn = Button("Continue", 0, 0, action=secret_level_code_prompt, font_size=80)
    continue_btn.rect.center = (WIDTH//2, HEIGHT//2)
    back_btn = Button("Back to Main Menu", 0, 0, action=main_menu, font_size=80)
    back_btn.rect.center = (WIDTH//2, HEIGHT//2 + 100)
    buttons = [continue_btn, back_btn]
    waiting = True
    while waiting:
        clear_screen()
        screen.blit(prompt_surface, ((WIDTH - prompt_surface.get_width())//2, HEIGHT//2 - 100))
        for btn in buttons:
            btn.draw(screen)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                for btn in buttons:
                    btn.click(event.pos)
        pygame.time.wait(100)

def secret_level_code_prompt():
    secret_code_local = secret_code
    user_input = ""
    fixed_box_width = 300
    input_box = pygame.Rect(WIDTH//2 - fixed_box_width//2, HEIGHT//2 + 50, fixed_box_width, 50)
    while True:
        clear_screen()
        prompt = "Enter secret code:"
        prompt_surface = large_font.render(prompt, True, (255,255,255))
        screen.blit(prompt_surface, ((WIDTH - prompt_surface.get_width())//2, HEIGHT//2 - 100))
        pygame.draw.rect(screen, (255,255,255), input_box, 2)
        rendered_text, _ = fit_text(user_input, 60, fixed_box_width-20)
        screen.blit(rendered_text, (input_box.x+10, input_box.y+10))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if user_input.strip() == "":
                        continue
                    if user_input.lower() == secret_code_local.lower():
                        start_level("secret")
                        return
                    else:
                        wrong_msg = large_font.render("Incorrect Code! Locked for 1 minute.", True, (255,0,0))
                        screen.blit(wrong_msg, ((WIDTH - wrong_msg.get_width())//2, HEIGHT//2+120))
                        pygame.display.update()
                        lock_start = time.time()
                        lock_duration = 60  # 1 minute lockout
                        while time.time() - lock_start < lock_duration:
                            clear_screen()
                            remaining_lock = int(lock_duration - (time.time() - lock_start))
                            lock_msg = large_font.render(f"Locked: {remaining_lock} seconds remaining", True, (255,0,0))
                            screen.blit(lock_msg, ((WIDTH - lock_msg.get_width())//2, HEIGHT//2))
                            pygame.display.update()
                            for e in pygame.event.get():
                                if e.type == pygame.QUIT:
                                    pygame.quit()
                                    return
                        user_input = ""
                elif event.key == pygame.K_BACKSPACE:
                    user_input = user_input[:-1]
                else:
                    user_input += event.unicode

def secret_level():
    pass

def display_credits():
    if music_playing:
        pygame.mixer.music.load("title_music (no copyright).mp3")
        pygame.mixer.music.play(-1,0.0)
    try:
        with open("credits.txt", "r") as f:
            text = f.read()
    except FileNotFoundError:
        text = "Credits file not found!"
    credits_screen(text.split("\n"))

def credits_screen(lines):
    clock = pygame.time.Clock()
    y_pos = HEIGHT
    scroll_speed = HEIGHT/10
    running = True
    while running:
        dt = clock.tick(60)/1000.0
        clear_screen()
        current_y = y_pos
        for line in lines:
            ts = small_font.render(line, True, (255,255,255))
            screen.blit(ts, ((WIDTH - ts.get_width())//2, current_y))
            current_y += small_font.size(line)[1]+5
        y_pos -= scroll_speed*dt
        if current_y < 0:
            running = False
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_LEFT, pygame.K_RIGHT):
                    running = False
    main_menu()

def exit_game():
    pygame.quit()

def settings_menu():
    global music_volume, sound_effect_volume
    
    # Slider dimensions
    slider_width = 600
    slider_x = (WIDTH - slider_width) // 2
    
    # Adjust these percentages to move items around the screen.
    # Increasing them moves items further down.
    title_y_percent        = 0.15  # 15% from top
    music_slider_y_percent = 0.40  # 40% from top
    sfx_slider_y_percent   = 0.50  # 50% from top
    back_btn_y_percent     = 0.75  # 75% from top

    # Convert percentage to actual y-coordinates.
    title_y        = int(HEIGHT * title_y_percent)
    music_slider_y = int(HEIGHT * music_slider_y_percent)
    sfx_slider_y   = int(HEIGHT * sfx_slider_y_percent)
    back_btn_y     = int(HEIGHT * back_btn_y_percent)

    # Create slider objects for music and sound effect volume.
    music_slider = Slider("Music Volume", slider_x, music_slider_y, slider_width, initial_value=music_volume)
    sfx_slider   = Slider("Sound Effect Volume", slider_x, sfx_slider_y, slider_width, initial_value=sound_effect_volume)

    # Make sliders bigger.
    music_slider.height = 30
    music_slider.knob_radius = 15
    sfx_slider.height = 30
    sfx_slider.knob_radius = 15

    # Create a "Back to Main Menu" button, centered horizontally at back_btn_y.
    back_btn = Button("Back to Main Menu", 0, 0, action=main_menu, font_size=80)
    back_btn.rect.center = (WIDTH // 2, back_btn_y)

    # Larger title font.
    title_font = pygame.font.Font(None, 120)
    # Larger font for slider labels.
    slider_label_font = pygame.font.Font(None, 60)

    running = True
    while running:
        clear_screen()

        # Render the "SETTINGS" title near the top, centered horizontally.
        title_surface = title_font.render("SETTINGS", True, (255, 255, 255))
        screen.blit(
            title_surface,
            (
                (WIDTH - title_surface.get_width()) // 2,
                title_y
            )
        )

        # Draw the sliders and the back button.
        music_slider.draw(screen, slider_label_font)
        sfx_slider.draw(screen, slider_label_font)
        back_btn.draw(screen)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return

            # Let the sliders handle mouse events for dragging the knob.
            music_slider.handle_event(event)
            sfx_slider.handle_event(event)

            # Check if user clicked the Back button.
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_btn.rect.collidepoint(event.pos):
                    running = False
                    # Save updated volumes and return to main menu.
                    music_volume = music_slider.value
                    sound_effect_volume = sfx_slider.value
                    pygame.mixer.music.set_volume(music_volume)
                    main_menu()
                    return

# Also update the Slider's draw() method to add more space between label and bar:
class Slider:
    def __init__(self, label, x, y, width, min_value=0.0, max_value=1.0, step=0.1, initial_value=0.5):
        self.label = label
        self.x = x
        self.y = y
        self.width = width
        self.height = 20
        self.min_value = min_value
        self.max_value = max_value
        self.step = step
        self.value = initial_value
        self.knob_radius = 10
        self.dragging = False

    def draw(self, surface, font_obj):
        # Draw label with current value, now 40 pixels above the slider bar.
        label_surface = font_obj.render(f"{self.label}: {self.value:.1f}", True, (255,255,255))
        surface.blit(label_surface, (self.x, self.y - 40))
        # Draw slider track.
        pygame.draw.rect(surface, (200,200,200), (self.x, self.y, self.width, self.height))
        # Draw knob.
        knob_x = self.x + int((self.value - self.min_value) / (self.max_value - self.min_value) * self.width)
        pygame.draw.circle(surface, (100,100,100), (knob_x, self.y + self.height//2), self.knob_radius)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            knob_x = self.x + int((self.value - self.min_value) / (self.max_value - self.min_value) * self.width)
            if (mouse_x - knob_x)**2 + (mouse_y - (self.y + self.height//2))**2 <= self.knob_radius**2:
                self.dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            mouse_x, _ = event.pos
            relative_x = mouse_x - self.x
            relative_x = max(0, min(self.width, relative_x))
            ratio = relative_x / self.width
            new_value = self.min_value + ratio * (self.max_value - self.min_value)
            steps = round((new_value - self.min_value) / self.step)
            self.value = self.min_value + steps * self.step
            self.value = max(self.min_value, min(self.max_value, self.value))

def main_menu():
    pygame.mixer.music.stop()
    # NEW: Replace music toggle button with a Settings button.
    start_btn = Button("Start Game", 0, 250, action=start_game, font_size=80)
    settings_btn = Button("Settings", 0, 350, action=settings_menu, font_size=80)
    credits_btn = Button("Credits", 0, 450, action=display_credits, font_size=80)
    exit_btn = Button("Exit", 0, 550, action=exit_game, font_size=80)
    for btn in (start_btn, settings_btn, credits_btn, exit_btn):
        btn.rect.x = (WIDTH - btn.rect.width)//2
    menu_buttons = [start_btn, settings_btn, credits_btn, exit_btn]
    menu_screen(menu_buttons)

def menu_screen(menu_buttons):
    running = True
    title_text = extra_large_font.render("Shadow Protocol", True, (255,255,255))
    while running:
        clear_screen()
        screen.blit(title_text, ((WIDTH - title_text.get_width())//2, 150))
        for button in menu_buttons:
            button.draw(screen)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for button in menu_buttons:
                    button.click(event.pos)

if __name__ == "__main__":
    main_menu()
    pygame.quit()